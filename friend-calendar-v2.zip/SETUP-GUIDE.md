# Friend Calendar - Setup Guide

Two things to do: set up a free Firebase database, then deploy. Total time: ~10 minutes.

## Step 1: Create a Firebase Project (free)

1. Go to **console.firebase.google.com** and sign in with Google
2. Click **"Create a project"** (name it anything, e.g. "friend-calendar")
3. Disable Google Analytics when asked (not needed), click Create
4. Once created, click the **web icon (</>)** to add a web app
   - Nickname: "friend-calendar"
   - Do NOT check "Firebase Hosting"
   - Click **Register app**
5. Copy the `firebaseConfig` values (apiKey, authDomain, etc.)
6. In the left sidebar: **Build > Realtime Database > Create Database**
   - Any location, **Start in locked mode**, click Enable
7. Click the **Rules** tab. Replace everything with:
   ```json
   {
     "rules": {
       ".read": true,
       ".write": true
     }
   }
   ```
   Click **Publish**.

## Step 2: Edit config.json

Open `config.json` in this folder with any text editor. Replace the placeholders:

```json
{
  "apiKey": "AIzaSy...",
  "authDomain": "your-project.firebaseapp.com",
  "databaseURL": "https://your-project-default-rtdb.firebaseio.com",
  "projectId": "your-project",
  "storageBucket": "your-project.firebasestorage.app",
  "messagingSenderId": "123456789",
  "appId": "1:123456789:web:abc123"
}
```

## Step 3: Deploy to Netlify

1. Go to **app.netlify.com**
2. Open your existing site (roaring-axolotl) or go to Sites > Add new site > Deploy manually
3. **Drag this entire folder** (the one containing index.html) onto the deploy area
4. Done! Share the URL with your friends.
